const STORAGE_USER_KEY = 'buscity_user';
const STORAGE_HISTORY_KEY = 'buscity_history';

const routesData = [
    {
        id: 1,
        name: 'Маршрут №1',
        from: 'Площадь Октября',
        to: 'Посёлок Южный',
        stops: ['Площадь Октября', 'Проспект Ленина', 'Улица Молодёжная', 'Посёлок Южный'],
        buses: ['ПАЗ-3205', 'ЛиАЗ-5292'],
        schedule: [
            '07:00–10:00 каждые 7 минут',
            '10:00–22:00 каждые 15 минут'
        ],
        price: 35
    },
    {
        id: 2,
        name: 'Маршрут №2',
        from: 'Вокзал',
        to: 'Новый рынок',
        stops: ['Вокзал', 'Улица Ползунова', 'Площадь Победы', 'Новый рынок'],
        buses: ['МАЗ-103', 'ЛиАЗ-6213'],
        schedule: [
            '06:30–09:30 каждые 10 минут',
            '09:30–21:30 каждые 18 минут'
        ],
        price: 32
    },
    {
        id: 3,
        name: 'Маршрут №3',
        from: 'Северо-Западная',
        to: 'Центр',
        stops: ['Северо-Западная', 'Улица Георгиева', 'Проспект Строителей', 'Центр'],
        buses: ['ПАЗ-4234'],
        schedule: [
            '07:00–11:00 каждые 8 минут',
            '11:00–20:00 каждые 20 минут'
        ],
        price: 30
    },
    {
        id: 4,
        name: 'Маршрут №4',
        from: 'Посёлок Восточный',
        to: 'Площадь Ленина',
        stops: ['Посёлок Восточный', 'Улица Энтузиастов', 'Проспект Космонавтов', 'Площадь Ленина'],
        buses: ['ЛиАЗ-5292', 'НЕФАЗ-5299'],
        schedule: [
            '06:00–09:00 каждые 6 минут',
            '09:00–23:00 каждые 14 минут'
        ],
        price: 38
    }
];

function getCurrentUser() {
    const raw = localStorage.getItem(STORAGE_USER_KEY);
    if (!raw) return null;
    try {
        return JSON.parse(raw);
    } catch {
        return null;
    }
}

function setCurrentUser(user) {
    if (!user) {
        localStorage.removeItem(STORAGE_USER_KEY);
    } else {
        localStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
    }
}

function getHistory() {
    const raw = localStorage.getItem(STORAGE_HISTORY_KEY);
    if (!raw) return [];
    try {
        return JSON.parse(raw);
    } catch {
        return [];
    }
}

function addHistoryItem(item) {
    const history = getHistory();
    history.push(item);
    localStorage.setItem(STORAGE_HISTORY_KEY, JSON.stringify(history));
}

function generateTicketCode(route, date) {
    const base = route.name + route.from + route.to + date + Date.now();
    let hash = 0;
    for (let i = 0; i < base.length; i++) {
        hash = (hash << 5) - hash + base.charCodeAt(i);
        hash |= 0;
    }
    return 'TICKET-' + Math.abs(hash).toString(16).toUpperCase().slice(0, 10);
}

function initHeaderAuthState() {
    const user = getCurrentUser();
    const page = document.body.dataset.page;
    const authBtn = document.getElementById('authBtn') || document.getElementById('authBtnProfile');
    const authBtnMobile = document.getElementById('authBtnMobile') || document.getElementById('authBtnProfileMobile');
    if (user) {
        if (authBtn) {
            authBtn.textContent = 'Выйти';
            authBtn.href = '#';
            authBtn.addEventListener('click', e => {
                e.preventDefault();
                setCurrentUser(null);
                window.location.href = 'index.html';
            });
        }
        if (authBtnMobile) {
            authBtnMobile.textContent = 'Выйти';
            authBtnMobile.href = '#';
            authBtnMobile.addEventListener('click', e => {
                e.preventDefault();
                setCurrentUser(null);
                window.location.href = 'index.html';
            });
        }
    } else {
        if (page === 'profile') {
            window.location.href = 'login.html';
        }
    }
}

function getStoredTheme() {
    return localStorage.getItem('buscity_theme') || 'light';
}

function applyTheme(theme) {
    document.documentElement.dataset.theme = theme;
    const toggle = document.getElementById('themeToggle');
    const toggleMobile = document.getElementById('themeToggleMobile');
    const icon = theme === 'dark' ? '☀️' : '🌙';
    if (toggle) toggle.textContent = icon;
    if (toggleMobile) toggleMobile.textContent = icon;
}

function toggleTheme() {
    const next = getStoredTheme() === 'dark' ? 'light' : 'dark';
    localStorage.setItem('buscity_theme', next);
    applyTheme(next);
}

function initThemeToggle() {
    applyTheme(getStoredTheme());
    const toggle = document.getElementById('themeToggle');
    const toggleMobile = document.getElementById('themeToggleMobile');
    if (toggle) toggle.addEventListener('click', toggleTheme);
    if (toggleMobile) toggleMobile.addEventListener('click', toggleTheme);
}

function initBurger() {
    const burgerBtn = document.getElementById('burgerBtn');
    const mobileMenu = document.getElementById('mobileMenu');
    if (!burgerBtn || !mobileMenu) return;
    burgerBtn.addEventListener('click', () => {
        mobileMenu.style.display = mobileMenu.style.display === 'flex' ? 'none' : 'flex';
    });
}

function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'flex';
}

function closeModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.style.display = 'none');
}

function initModals() {
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
        btn.addEventListener('click', closeModals);
    });
    document.addEventListener('click', e => {
        if (e.target.classList.contains('modal-overlay')) {
            closeModals();
        }
    });
}

function initIndexPage() {
    const page = document.body.dataset.page;
    if (page !== 'index') return;

    const routeSelectBtn = document.getElementById('routeSelectBtn');
    const selectedRoute = document.getElementById('selectedRoute');
    const routeDetails = document.getElementById('routeDetails');
    const routeTitle = document.getElementById('routeTitle');
    const routeStops = document.getElementById('routeStops');
    const routeBuses = document.getElementById('routeBuses');
    const routeSchedule = document.getElementById('routeSchedule');
    const routePrice = document.getElementById('routePrice');
    const payBtn = document.getElementById('payBtn');
    const payModal = document.getElementById('payModal');
    const payRouteInfo = document.getElementById('payRouteInfo');
    const confirmPayBtn = document.getElementById('confirmPayBtn');
    const payDate = document.getElementById('payDate');
    const payMethod = document.getElementById('payMethod');
    const routesTableBody = document.getElementById('routesTableBody');

    let currentRoute = null;

    routesTableBody.innerHTML = '';
    routesData.forEach(r => {
        const tr = document.createElement('tr');
        tr.className = 'route-row';
        tr.dataset.routeId = r.id;
        const td1 = document.createElement('td');
        td1.textContent = r.name;
        const td2 = document.createElement('td');
        td2.textContent = r.from + ' — ' + r.to;
        tr.appendChild(td1);
        tr.appendChild(td2);
        routesTableBody.appendChild(tr);
    });

    if (routeSelectBtn) {
        routeSelectBtn.addEventListener('click', () => {
            openModal('routeModal');
        });
    }

    if (selectedRoute) {
        selectedRoute.addEventListener('click', () => {
            openModal('routeModal');
        });
    }

    document.querySelectorAll('.route-row').forEach(row => {
        row.addEventListener('click', () => {
            const id = parseInt(row.dataset.routeId, 10);
            const r = routesData.find(x => x.id === id);
            if (!r) return;
            currentRoute = r;
            selectedRoute.dataset.routeId = r.id;
            selectedRoute.textContent = r.name + ': ' + r.from + ' — ' + r.to;
            routeTitle.textContent = r.name + ' • ' + r.from + ' — ' + r.to;
            routeStops.innerHTML = '';
            r.stops.forEach(s => {
                const li = document.createElement('li');
                li.textContent = s;
                routeStops.appendChild(li);
            });
            routeBuses.innerHTML = '';
            r.buses.forEach(b => {
                const li = document.createElement('li');
                li.textContent = b;
                routeBuses.appendChild(li);
            });
            routeSchedule.innerHTML = '';
            r.schedule.forEach(s => {
                const li = document.createElement('li');
                li.textContent = s;
                routeSchedule.appendChild(li);
            });
            routePrice.textContent = 'Стоимость: ' + r.price + ' ₽';
            routeDetails.style.display = 'block';
            closeModals();
        });
    });

    if (payBtn) {
        payBtn.addEventListener('click', () => {
            if (!currentRoute) return;
            payRouteInfo.textContent = currentRoute.name + ' • ' + currentRoute.from + ' — ' + currentRoute.to + ' • ' + currentRoute.price + ' ₽';
            payDate.value = '';
            openModal('payModal');
        });
    }

    if (confirmPayBtn) {
        confirmPayBtn.addEventListener('click', () => {
            if (!currentRoute) return;
            if (!payDate.value) {
                alert('Выберите дату поездки');
                return;
            }
            const user = getCurrentUser();
            const ticketCode = generateTicketCode(currentRoute, payDate.value);
            addHistoryItem({
                date: payDate.value,
                route: currentRoute.name + ' ' + currentRoute.from + ' — ' + currentRoute.to,
                price: currentRoute.price,
                code: ticketCode
            });
            closeModals();
            if (user) {
                alert('Оплата прошла успешно. Код билета: ' + ticketCode);
            } else {
                alert('Оплата прошла успешно. Рекомендуем авторизоваться, чтобы сохранить билет в профиле.');
            }
        });
    }
}

function initLoginPage() {
    const page = document.body.dataset.page;
    if (page !== 'login') return;

    const form = document.getElementById('loginForm');
    const errorBox = document.getElementById('loginError');
    const emailInput = document.getElementById('loginEmail');
    const passInput = document.getElementById('loginPassword');

    form.addEventListener('submit', e => {
        e.preventDefault();
        const email = emailInput.value.trim();
        const password = passInput.value.trim();
        if (!email || !password) {
            errorBox.textContent = 'Введите email и пароль';
            errorBox.style.display = 'block';
            return;
        }
        const user = getCurrentUser();
        if (!user || user.email !== email) {
            errorBox.textContent = 'Пользователь не найден. Зарегистрируйтесь.';
            errorBox.style.display = 'block';
            return;
        }
        errorBox.style.display = 'none';
        window.location.href = 'index.html';
    });
}

function initRegisterPage() {
    const page = document.body.dataset.page;
    if (page !== 'register') return;

    const form = document.getElementById('registerForm');
    const errorBox = document.getElementById('registerError');
    const nameInput = document.getElementById('regName');
    const phoneInput = document.getElementById('regPhone');
    const emailInput = document.getElementById('regEmail');
    const passInput = document.getElementById('regPassword');
    const pass2Input = document.getElementById('regPassword2');

    form.addEventListener('submit', e => {
        e.preventDefault();
        const name = nameInput.value.trim();
        const phone = phoneInput.value.trim();
        const email = emailInput.value.trim();
        const pass = passInput.value.trim();
        const pass2 = pass2Input.value.trim();
        if (!name || !phone || !email || !pass || !pass2) {
            errorBox.textContent = 'Заполните все поля';
            errorBox.style.display = 'block';
            return;
        }
        if (pass !== pass2) {
            errorBox.textContent = 'Пароли не совпадают';
            errorBox.style.display = 'block';
            return;
        }
        const user = { name, phone, email };
        setCurrentUser(user);
        errorBox.style.display = 'none';
        window.location.href = 'index.html';
    });
}

function initProfilePage() {
    const page = document.body.dataset.page;
    if (page !== 'profile') return;

    const user = getCurrentUser();
    if (!user) {
        window.location.href = 'login.html';
        return;
    }

    const nameEl = document.getElementById('profileName');
    const phoneEl = document.getElementById('profilePhone');
    const emailEl = document.getElementById('profileEmail');
    const historyBtn = document.getElementById('historyBtn');
    const qrBtn = document.getElementById('qrBtn');
    const historyTableBody = document.querySelector('#historyTable tbody');
    const historyEmpty = document.getElementById('historyEmpty');
    const qrCodeBox = document.getElementById('qrCodeBox');
    const changeNameBtn = document.getElementById('changeNameBtn');
    const changePhoneBtn = document.getElementById('changePhoneBtn');
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    const editModal = document.getElementById('editModal');
    const editModalTitle = document.getElementById('editModalTitle');
    const editLabel = document.getElementById('editLabel');
    const editInput = document.getElementById('editInput');
    const editSaveBtn = document.getElementById('editSaveBtn');

    nameEl.textContent = user.name;
    phoneEl.textContent = user.phone;
    emailEl.textContent = user.email;

    const history = getHistory();
    historyTableBody.innerHTML = '';
    if (history.length === 0) {
        historyEmpty.style.display = 'block';
    } else {
        historyEmpty.style.display = 'none';
        history.forEach(h => {
            const tr = document.createElement('tr');
            const td1 = document.createElement('td');
            const td2 = document.createElement('td');
            const td3 = document.createElement('td');
            td1.textContent = h.date;
            td2.textContent = h.route;
            td3.textContent = h.price + ' ₽';
            tr.appendChild(td1);
            tr.appendChild(td2);
            tr.appendChild(td3);
            historyTableBody.appendChild(tr);
        });
    }

    const lastTicket = history[history.length - 1];
if (lastTicket) {
    const qr = new QRious({
        element: document.getElementById('qrCanvas'),
        value: lastTicket.code,
        size: 200,
        level: 'H'
    });
    document.getElementById('qrText').textContent = lastTicket.code;
} else {
    document.getElementById('qrCanvas').style.display = 'none';
    document.getElementById('qrText').textContent = 'Нет активного билета';
}


    if (historyBtn) {
        historyBtn.addEventListener('click', () => {
            openModal('historyModal');
        });
    }

    if (qrBtn) {
        qrBtn.addEventListener('click', () => {
            openModal('qrModal');
        });
    }

    function openEditModal(field) {
        if (field === 'name') {
            editModalTitle.textContent = 'Изменить имя';
            editLabel.textContent = 'Новое имя';
            editInput.value = user.name;
        } else if (field === 'phone') {
            editModalTitle.textContent = 'Изменить телефон';
            editLabel.textContent = 'Новый телефон';
            editInput.value = user.phone;
        } else if (field === 'password') {
            editModalTitle.textContent = 'Изменить пароль';
            editLabel.textContent = 'Новый пароль';
            editInput.value = '';
        }
        editInput.dataset.field = field;
        openModal('editModal');
    }

    if (changeNameBtn) {
        changeNameBtn.addEventListener('click', () => openEditModal('name'));
    }
    if (changePhoneBtn) {
        changePhoneBtn.addEventListener('click', () => openEditModal('phone'));
    }
    if (changePasswordBtn) {
        changePasswordBtn.addEventListener('click', () => openEditModal('password'));
    }

    if (editSaveBtn) {
        editSaveBtn.addEventListener('click', () => {
            const field = editInput.dataset.field;
            const value = editInput.value.trim();
            if (!value) {
                alert('Поле не может быть пустым');
                return;
            }
            if (field === 'name') {
                user.name = value;
                nameEl.textContent = value;
            } else if (field === 'phone') {
                user.phone = value;
                phoneEl.textContent = value;
            } else if (field === 'password') {
                alert('Пароль изменён (в демо не сохраняется)');
            }
            setCurrentUser(user);
            closeModals();
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initBurger();
    initModals();
    initHeaderAuthState();
    initThemeToggle();
    initIndexPage();
    initLoginPage();
    initRegisterPage();
    initProfilePage();
});
